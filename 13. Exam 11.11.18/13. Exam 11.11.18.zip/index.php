<?php
include 'common.php';

$home= new \Http\HomeHttp($template);
$home->index();