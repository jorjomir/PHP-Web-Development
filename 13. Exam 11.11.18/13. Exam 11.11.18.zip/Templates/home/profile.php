<?php /** @var \DTO\UserDTO $data */?>
<h1>Hello, <?=$data->getFullName()?></h1>
<a href="addBook.php">Add new Book</a> | <a href="logout.php">logout</a><br/>
<a href="myBooks.php">My Books</a><br/>
<a href="allBooks.php">All Books</a>