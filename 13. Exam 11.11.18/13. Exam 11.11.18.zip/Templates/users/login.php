<form method="post">
    Username: <input type="text" name="username"><br/>
    Password: <input type="password" name="password"><br/>
    <button type="submit">Login Now!</button>
</form>