<form method="post">
    Username: <input type="text" name="username"><br/>
    Password: <input type="password" name="password"><br/>
    Confirm password: <input type="password" name="confirm_password"><br/>
    Full Name: <input type="text" name="full_name"><br/>
    Born on: <input type="date" name="born_on"><br/>
    <button type="submit">Register!</button>
</form>